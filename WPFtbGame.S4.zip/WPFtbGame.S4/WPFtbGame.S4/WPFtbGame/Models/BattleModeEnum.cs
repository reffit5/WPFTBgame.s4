﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFtbGame.Models
{
    public enum BattleModeName
    {
        ATTACK,
        DEFEND,
        RETREAT
    }
}
